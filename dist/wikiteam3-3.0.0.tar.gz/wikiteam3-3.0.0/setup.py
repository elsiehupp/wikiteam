# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dumpgenerator']

package_data = \
{'': ['*']}

modules = \
['test_dumpgenerator']
install_requires = \
['PyMySQL>=1.0.2,<2.0.0',
 'argparse>=1.4.0,<2.0.0',
 'file_read_backwards>=2.0.0,<3.0.0',
 'internetarchive>=2.1.0,<3.0.0',
 'lxml>=4.6.5,<5.0.0',
 'mwclient>=0.10.1,<0.11.0',
 'pywikibot>=6.6.1,<7.0.0',
 'requests>=2.26.0,<3.0.0',
 'urllib3>=1.26.7,<2.0.0',
 'wikitools3>=3.0.0,<4.0.0']

entry_points = \
{'console_scripts': ['dumpgenerator = wikiteam3.dumpgenerator:main',
                     'test-dumpgenerator = tests.test_dumpgenerator:main']}

setup_kwargs = {
    'name': 'wikiteam3',
    'version': '3.0.0',
    'description': 'Tools for downloading and preserving wikis. We archive wikis, from Wikipedia to tiniest wikis. As of 2020, WikiTeam has preserved more than 250,000 wikis.',
    'long_description': '# `wikiteam3`\n\n***We archive wikis, from Wikipedia to the tiniest wikis***\n\n`wikiteam3` is an ongoing project to port the legacy [`wikiteam`][](https://github.com/WikiTeam/wikiteam) toolset to Python 3 and PyPI to make it more accessible for today\'s archivers.\n\nMost of the focus has been on the core `dumpgenerator` tool, but Python 3 versions of the other `wikiteam` tools may be added over time.\n\n## `wikiteam3` Toolset\n\n`wikiteam3` is a set of tools for archiving wikis. The tools work on MediaWiki wikis, but the team hopes to expand to other wiki engines. As of 2020, WikiTeam has preserved more than [250,000 wikis][](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups), several wikifarms, regular Wikipedia dumps and [34 TB of Wikimedia Commons images][](https://archive.org/details/wikimediacommons).\n\nThere are [thousands](http://wikiindex.org) of [wikis][](https://wikiapiary.com) in the Internet. Every day some of them are no longer publicly available and, due to lack of backups, lost forever. Millions of people download tons of media files (movies, music, books, etc) from the Internet, serving as a kind of distributed backup. Wikis, most of them under free licenses, disappear from time to time because nobody grabbed a copy of them. That is a shame that we would like to solve.\n\n## WikiTeam Team\n\n**WikiTeam** is the [Archive Team](http://www.archiveteam.org) ([GitHub][](https://github.com/ArchiveTeam)) subcommittee on wikis.\n\nIt was founded and originally developed by [Emilio J. Rodríguez-Posada][](https://github.com/emijrp), a Wikipedia veteran editor and amateur archivist. Many people have helped by sending suggestions, [reporting bugs][](https://github.com/WikiTeam/wikiteam/issues), writing [documentation][](https://github.com/WikiTeam/wikiteam/wiki), providing help in the [mailing list](http://groups.google.com/group/wikiteam-discuss) and making [wiki backups][](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups). Thanks to all, especially to: [Federico Leva][](https://github.com/nemobis), [Alex Buie][](https://github.com/ab2525), [Scott Boyd](http://www.sdboyd56.com), [Hydriz][](https://github.com/Hydriz), Platonides, Ian McEwen, [Mike Dupont][](https://github.com/h4ck3rm1k3), [balr0g][](https://github.com/balr0g) and [PiRSquared17][](https://github.com/PiRSquared17).\n\n[Documentation](https://github.com/WikiTeam/wikiteam/wiki/Tutorial)\n![Documentation](https://upload.wikimedia.org/wikipedia/commons/f/f3/Nuvola_apps_Wild.png)\n\n[Source code](https://raw.githubusercontent.com/WikiTeam/wikiteam/master/dumpgenerator.py)\n[Source code]("http://upload.wikimedia.org/wikipedia/commons/2/2a/Nuvola_apps_kservices.png)\n\n[Download available backups](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups)\n![Download available backups](https://upload.wikimedia.org/wikipedia/commons/3/37/Nuvola_devices_3floppy_mount.png)\n\n[Community](https://groups.google.com/group/wikiteam-discuss)\n![Community](https://upload.wikimedia.org/wikipedia/commons/0/0f/Nuvola_apps_kuser.png)\n\n[Follow us on Twitter](https://twitter.com/_WikiTeam)\n![Follow us on Twitter](https://upload.wikimedia.org/wikipedia/commons/e/eb/Twitter_logo_initial.png)\n\n## Using `wikiteam3`\n\nThis is a very quick guide for the most used features of WikiTeam tools. For further information, read the [tutorial][](https://github.com/WikiTeam/wikiteam/wiki/Tutorial) and the rest of the [documentation][](https://github.com/WikiTeam/wikiteam/wiki). You can also ask in the [mailing list](http://groups.google.com/group/wikiteam-discuss).\n\n### Getting Started\n\nThe recommended way to install `wikiteam3` is from [PyPI][](https://pypi.org/project/wikiteams3/):\n\n```bash\npip install wikiteam3\n```\n\n`wikiteam3` requires [Python 3.8][](https://www.python.org/downloads/release/python-380/) or later (less than 4.0), but you may be able to get it run with earlier versions of Python 3.\n\nIf you\'d like to manually install `wikiteam3` from a cloned or downloaded copy of this repository, run the following commands from the downloaded base directory:\n\n```bash\ncurl -sSL https://install.python-poetry.org | python3 -\npoetry install\npoetry build\npip install --force-reinstall dist/*.whl\n```\n\nIn either case, to uninstall `wikiteam3` run this command (from any local directory):\n\n```bash\npip uninstall wikiteam3\n```\n\n### Using `dumpgenerator`\n\nAfter installing `wikiteam3` using `pip` you should be able to use the `dumpgenerator` command from any local directory.\n\nFor basic usage, you can run `dumpgenerator` in the directory where you\'d like the download to be.\n\nTo download any wiki, use one of the following options:\n\n1. Complete XML histories and images\n\n```bash\ndumpgenerator http://wiki.domain.org --xml --images\n```\n\nIf the script can\'t find itself the API and/or index.php paths, then you can provide them:\n\n```bash\ndumpgenerator --api-url http://wiki.domain.org/w/api.php --xml --images\n```\n\n```bash\ndumpgenerator --api-url http://wiki.domain.org/w/api.php --index-url http://wiki.domain.org/w/index.php --xml --images\n```\n\nIf you only want the XML histories, just use `--xml`. For only the images, just `--images`. For only the current version of every page, `--xml --current`.\n\nYou can resume an aborted download:\n\n```bash\ndumpgenerator --api-url http://wiki.domain.org/w/api.php --xml --images --resume --path=/path/to/incomplete-dump\n```\n\nSee more options:\n\n```bash\ndumpgenerator --help\n```\n\n### Download Wikimedia dumps\n\nTo download [Wikimedia XML dumps](http://dumps.wikimedia.org/backup-index.html) (Wikipedia, Wikibooks, Wikinews, etc) you can run:\n\n```bash\npoetry run python wikipediadownloader.py\n```\n\n(download all projects)\n\nSee more options:\n\n`poetry run python wikipediadownloader.py --help`\n\n## Developers\n\n[![Build Status][](https://travis-ci.org/WikiTeam/wikiteam.svg)][](https://travis-ci.org/WikiTeam/wikiteam)\n\n> **Note:** Tests are not currently working. These instructions will be updated ASAP.\n\nYou can run tests easily by using the [tox][](https://pypi.python.org/pypi/tox) command.  It is probably already present in your operating system, you would need version 1.6.  If it is not, you can download it from pypi with: `pip install tox`.\n\nExample usage:\n\n```bash\n$ tox\npy27 runtests: commands[0] | nosetests --nocapture --nologcapture\nChecking http://wiki.annotation.jp/api.php\nTrying to parse かずさアノテーション - ソーシャル・ゲノム・アノテーション.jpg from API\nRetrieving image filenames\n.    Found 266 images\n.\n-------------------------------------------\nRan 1 test in 2.253s\n\nOK\n_________________ summary _________________\npy27: commands succeeded\ncongratulations :)\n$\n```\n',
    'author': 'WikiTeam Contributors',
    'author_email': 'https://github.com/WikiTeam/wikiteam/graphs/contributors',
    'maintainer': 'Federico Leva',
    'maintainer_email': 'https://github.com/nemobis',
    'url': 'https://wiki.archiveteam.org/index.php/WikiTeam',
    'packages': packages,
    'package_data': package_data,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
