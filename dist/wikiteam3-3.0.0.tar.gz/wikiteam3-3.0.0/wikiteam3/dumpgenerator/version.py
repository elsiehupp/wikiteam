__VERSION__: str = "3.0.0"  # major, minor, micro: semver.org


def getVersion() -> str:
    return __VERSION__
